import { PROVIDER_RESPONSE_SUCCESS, AMBI_RESPONSE_SUCCESS } from './types'

export function sendProviderResponse(payload) {
  return {
    type: PROVIDER_RESPONSE_SUCCESS,
    payload,
  }
}

export function sendAmbiResponse(payload) {
  console.log(`action - payload: ${payload}`)
  return {
    type: AMBI_RESPONSE_SUCCESS,
    payload,
  }
}
