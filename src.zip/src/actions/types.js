export const PROVIDER_RESPONSE_SUCCESS = 'provider_response_success'
export const AMBI_RESPONSE_SUCCESS = 'ambi_response_success'
